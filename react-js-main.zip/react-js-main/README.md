📰 React Social Media Embed
Easily embed social media posts from Facebook in React.
Overview
Easily embed content from several popular social media platforms in React.

All embeds only require a URL to the post. No API token is needed.

Currently supporting: Facebook.
