Core functionalities of a Social Media App or Website created using Node.js, Express.js and MongoDB as database.
